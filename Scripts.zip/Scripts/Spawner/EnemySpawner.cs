using UnityEngine;
using System;
using System.Collections;
using TMPro;

public class EnemySpawner : MonoBehaviour
{
    [Header("Primary Enemies (Clusters)")]
    public GameObject[] primaryEnemyPrefabs;

    [Header("Side Enemies (Streams)")]
    public GameObject[] sideEnemyPrefabs;

    [Header("Cluster Settings")]
    public int minClusterSize = 3;
    public int maxClusterSize = 8;
    public float minClusterRadius = 2f;
    public float maxClusterRadius = 5f;

    [Header("Spawn Timing")]
    public float clusterSpawnInterval = 4f;
    public float sideSpawnInterval = 1.2f;

    [Header("Spawn Distance")]
    public float minSpawnDistance = 8f;
    public float maxSpawnDistance = 15f;

    [Header("Day Settings")]
    public int currentDay = 1;
    public int baseEnemyCount = 50;
    public float dayGrowthMultiplier = 1.25f;

    [Header("XP Progress")]
    public int currentXP;
    public int xpRequired;

    [Header("UI")]
    public TextMeshProUGUI remainingEnemiesText;
    public TextMeshProUGUI dayText;
    public UpgradeScreen upgradeScreen;

    private Camera mainCamera;

    private float clusterTimer;
    private float sideTimer;

    private int totalEnemiesThisDay;
    private int enemiesKilled;
    private bool spawning = true;

    // Start is called before the first frame update
    void Start()
    {
        mainCamera = Camera.main;
        StartDay(currentDay);
    }

    // Update is called once per frame
    void Update()
    {
        if (!spawning) return;

        clusterTimer += Time.deltaTime;
        sideTimer += Time.deltaTime;

        if (clusterTimer >= clusterSpawnInterval && EnemiesRemainingToSpawn() > 0)
        {
            SpawnPrimaryCluster();
            clusterTimer = 0f;
        }

        if (sideTimer >= sideSpawnInterval && EnemiesRemainingToSpawn() > 0)
        {
            SpawnSideEnemy();
            sideTimer = 0f;
        }

        UpdateRemainingEnemiesUI();
    }


    void StartDay(int day)
    {
        StartSpawning();
        totalEnemiesThisDay = Mathf.RoundToInt(baseEnemyCount * Mathf.Pow(dayGrowthMultiplier, day - 1));

        enemiesKilled = 0;
        currentXP = 0;
        xpRequired = totalEnemiesThisDay;

        clusterTimer = 0f;
        sideTimer = 0f;
        dayText.SetText("Day " + day);
    }

    public void NextDay()
    {
        currentDay++;
        StartDay(currentDay);
    }

    public int EnemiesRemainingToSpawn()
    {
        return totalEnemiesThisDay - enemiesKilled;
    }


    public void AddXP(int amount)
    {
        if (!spawning)
        {
            return;
        }
        currentXP += Mathf.CeilToInt( PlayerStats.GetXPGain(amount));

        if (currentXP >= xpRequired)
        {
            upgradeScreen.Show();
            StopSpawning();
            dayText.SetText("");
            remainingEnemiesText.SetText("Upgrade!");
        }
    }

    void SpawnPrimaryCluster()
    {
        if (primaryEnemyPrefabs.Length == 0) return;

        Vector2 center = GetRandomOffscreenPosition();
        int clusterSize = UnityEngine.Random.Range(minClusterSize, maxClusterSize + 1);
        float radius = UnityEngine.Random.Range(minClusterRadius, maxClusterRadius);

        for (int i = 0; i < clusterSize; i++)
        {
            if (EnemiesRemainingToSpawn() <= 0) break;

            Vector2 pos = center + UnityEngine.Random.insideUnitCircle * radius;
            SpawnEnemy(primaryEnemyPrefabs, pos);
        }
    }

    void SpawnSideEnemy()
    {
        if (sideEnemyPrefabs.Length == 0) return;

        Vector2 pos = GetRandomOffscreenPosition();
        SpawnEnemy(sideEnemyPrefabs, pos);
    }

    void SpawnEnemy(GameObject[] prefabs, Vector2 position)
    {
        GameObject prefab = prefabs[UnityEngine.Random.Range(0, prefabs.Length)];
        GameObject enemy = Instantiate(prefab, position, Quaternion.identity);

        Enemy enemyComp = enemy.GetComponent<Enemy>();
        if (enemyComp != null)
            enemyComp.onDeath += OnEnemyKilled;
    }

    // helpers

    Vector2 GetRandomOffscreenPosition()
    {
        Vector2 camMin = mainCamera.ViewportToWorldPoint(new Vector2(0, 0));
        Vector2 camMax = mainCamera.ViewportToWorldPoint(new Vector2(1, 1));

        float distance = UnityEngine.Random.Range(minSpawnDistance, maxSpawnDistance);
        int side = UnityEngine.Random.Range(0, 4);

        switch (side)
        {
            case 0: return new Vector2(UnityEngine.Random.Range(camMin.x, camMax.x), camMax.y + distance);
            case 1: return new Vector2(UnityEngine.Random.Range(camMin.x, camMax.x), camMin.y - distance);
            case 2: return new Vector2(camMin.x - distance, UnityEngine.Random.Range(camMin.y, camMax.y));
            default: return new Vector2(camMax.x + distance, UnityEngine.Random.Range(camMin.y, camMax.y));
        }
    }
    public void DeleteAllEnemies()
    {
        int enemyLayer = LayerMask.NameToLayer("Enemy");
        int enemyProjectileLayer = LayerMask.NameToLayer("EnemyProjectile");

        GameObject[] allObjects = FindObjectsOfType<GameObject>();

        foreach (GameObject obj in allObjects)
        {
            if (obj.layer == enemyLayer || obj.layer == enemyProjectileLayer)
            {
                Destroy(obj);
            }
        }
    }
    public void StopSpawning()
    {
        DeleteAllEnemies();
        spawning = false;
    }
    public void StartSpawning()
    {
        spawning = true;
    }
    void UpdateRemainingEnemiesUI()
    {
        if (remainingEnemiesText != null)
        {
            remainingEnemiesText.text = $"Day Progress: {currentXP} / {xpRequired}";
        }
    }

    void OnEnemyKilled()
    {
        enemiesKilled++;
    }
}
