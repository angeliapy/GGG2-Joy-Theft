using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BossSpawner : MonoBehaviour
{
    [Header("Boss")]
    public GameObject bossPrefab;
    private GameObject currentBoss;

    [Header("Enemy Spawner")]
    public EnemySpawner es;

    [Header("Dialogue")]
    public DialogueManager dialogueManager;
    public DialogueData[] beforeFightDialogues;
    public DialogueData[] afterFightDialogues;

    [Header("UI")]
    public GameObject bossHealthBar;
    public Image fillImage;

    private int currentDay = 0;

    // Start is called before the first frame update
    void Start()
    {
        bossHealthBar.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (currentBoss != null && fillImage != null)
        {
            Boss boss = currentBoss.GetComponent<Boss>();
            if (boss != null)
                fillImage.fillAmount = boss.currentHealth / boss.maxHealth;
        }
    }

    public void SpawnBoss()
    {
        if (currentDay < beforeFightDialogues.Length &&
            beforeFightDialogues[currentDay] != null)
        {
            dialogueManager.OnDialogueFinished = SpawnBossInternal;
            dialogueManager.StartDialogue(beforeFightDialogues[currentDay]);
            return;
        }

        SpawnBossInternal();
    }

    void SpawnBossInternal()
    {
        currentBoss = Instantiate(
            bossPrefab,
            transform.position,
            transform.rotation,
            transform
        );

        bossHealthBar.SetActive(true);
    }

    public void OnBossDefeated()
    {
        bossHealthBar.SetActive(false);
        currentBoss = null;

        if (currentDay < afterFightDialogues.Length &&
            afterFightDialogues[currentDay] != null)
        {
            dialogueManager.StartDialogue(afterFightDialogues[currentDay]);
        }

        NextDay();
    }

    void NextDay()
    {
        currentDay++;
        es.NextDay();
    }
}
