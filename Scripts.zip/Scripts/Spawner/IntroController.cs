using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class IntroController : MonoBehaviour
{
    public DialogueManager dialogueManager;
    public DialogueData introDialogue;

    public SpriteRenderer backgroundSprite;
    public SpriteRenderer boss;
    public float fadeDuration = 1.5f;

    public string nextSceneName = "SampleScene";

    // Start is called before the first frame update
    void Start()
    {
        SetAlpha(backgroundSprite, 1f);

        dialogueManager.OnDialogueFinished = OnIntroFinished;
        dialogueManager.StartDialogue(introDialogue);
    }

    void OnIntroFinished()
    {
        StartCoroutine(FadeOutAndLoad());
    }

    IEnumerator FadeOutAndLoad()
    {
        float t = 0f;
        while (t < 0.5f)
        {
            t += Time.deltaTime;
            SetAlpha(boss, Mathf.Lerp(1f, 0f, t / fadeDuration));
            yield return null;
        }
        t = 0f;
        while (t < fadeDuration)
        {
            t += Time.deltaTime;
            SetAlpha(backgroundSprite, Mathf.Lerp(1f, 0f, t / fadeDuration));
            yield return null;
        }

        SetAlpha(backgroundSprite, 0f);
        SceneManager.LoadScene(nextSceneName);
    }

    void SetAlpha(SpriteRenderer sr, float alpha)
    {
        Color c = sr.color;
        c.a = alpha;
        sr.color = c;
    }
}
