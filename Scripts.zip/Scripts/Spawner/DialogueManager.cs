using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class DialogueManager : MonoBehaviour
{
    [Header("UI References")]
    public Image speakerIcon;
    public TextMeshProUGUI speakerNameText;
    public TextMeshProUGUI dialogueText;
    public GameObject continueIcon;

    [Header("Typing Settings")]
    public float typingSpeed = 0.035f;
    public float punctuationPauseMultiplier = 6f;

    [Header("Audio (Optional)")]
    public AudioSource audioSource;
    public AudioClip typingSound;
    public float soundCooldown = 0.04f;

    public System.Action OnDialogueFinished;


    private DialogueData currentDialogue;
    private int currentLineIndex;
    private Coroutine typingCoroutine;
    private bool isTyping;
    private float lastSoundTime;

    // Start is called before the first frame update
    void Awake()
    {
        continueIcon.SetActive(false);
        dialogueText.text = "";
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
        {
            HandleInput();
        }
    }

    public void StartDialogue(DialogueData dialogue)
    {
        gameObject.SetActive(true);

        currentDialogue = dialogue;
        currentLineIndex = 0;
        ShowLine();
    }
    void ShowLine()
    {
        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);

        DialogueLine line = currentDialogue.lines[currentLineIndex];

        speakerNameText.text = line.speakerName;
        speakerIcon.sprite = line.speakerIcon;

        dialogueText.text = "";
        continueIcon.SetActive(false);

        typingCoroutine = StartCoroutine(TypeText(line.text));
    }

    IEnumerator TypeText(string text)
    {
        isTyping = true;
        lastSoundTime = 0f;

        foreach (char c in text)
        {
            dialogueText.text += c;

            PlayTypingSound();

            float delay = typingSpeed;

            if (IsPunctuation(c))
                delay *= punctuationPauseMultiplier;

            yield return new WaitForSeconds(delay);
        }

        isTyping = false;
        continueIcon.SetActive(true);
        StartCoroutine(AnimateContinueIcon());
    }

    void HandleInput()
    {
        if (currentDialogue == null) return;

        if (isTyping)
        {
            SkipTyping();
        }
        else
        {
            AdvanceLine();
        }
    }

    void SkipTyping()
    {
        StopCoroutine(typingCoroutine);
        dialogueText.text = currentDialogue.lines[currentLineIndex].text;
        isTyping = false;
        continueIcon.SetActive(true);
        StartCoroutine(AnimateContinueIcon());
    }

    void AdvanceLine()
    {
        currentLineIndex++;

        if (currentLineIndex >= currentDialogue.lines.Length)
        {
            EndDialogue();
        }
        else
        {
            ShowLine();
        }
    }

    void EndDialogue()
    {
        StopAllCoroutines();
        gameObject.SetActive(false);
        currentDialogue = null;

        OnDialogueFinished?.Invoke();
        OnDialogueFinished = null; // important: clear listeners
    }


    bool IsPunctuation(char c)
    {
        return c == '.' || c == ',' || c == '!' || c == '?' || c == '-';
    }

    void PlayTypingSound()
    {
        if (typingSound == null || audioSource == null) return;

        if (Time.time - lastSoundTime >= soundCooldown)
        {
            audioSource.PlayOneShot(typingSound);
            lastSoundTime = Time.time;
        }
    }

    IEnumerator AnimateContinueIcon()
    {
        CanvasGroup cg = continueIcon.GetComponent<CanvasGroup>();
        if (cg == null)
            cg = continueIcon.AddComponent<CanvasGroup>();

        while (!isTyping)
        {
            cg.alpha = Mathf.PingPong(Time.time * 2f, 1f);
            yield return null;
        }

        cg.alpha = 1f;
    }
}
