using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LaserSpawner : MonoBehaviour
{
    public GameObject laserPrefab;

    [Header("Pattern Settings")]
    public int gridCount = 4;
    public bool randomOrientation = true;
    public float repeatDelay = 6f;

    private Camera cam;
    private float camWidth;
    private float camHeight;

    private bool lasersActive;

    void Awake()
    {
        cam = Camera.main;

        camHeight = cam.orthographicSize * 2f;
        camWidth = camHeight * cam.aspect;
    }

    public void StartLasers()
    {
        if (lasersActive)
            return;

        lasersActive = true;
        InvokeRepeating(nameof(SpawnGrid), 0f, repeatDelay);
    }

    public void StopLasers()
    {
        if (!lasersActive)
            return;

        lasersActive = false;
        CancelInvoke(nameof(SpawnGrid));
    }

    void SpawnGrid()
    {
        Vector3 camCenter = cam.transform.position;
        float leftEdge = camCenter.x - camWidth / 2f;
        float bottomEdge = camCenter.y - camHeight / 2f;

        for (int i = 0; i < gridCount; i++)
        {
            bool vertical = true;

            if (randomOrientation)
                vertical = Random.Range(0, 2) == 0;

            if (vertical)
            {
                float xPos = leftEdge + (i + 0.5f) * (camWidth / gridCount);
                SpawnLaser(
                    new Vector3(xPos, camCenter.y, -1f),
                    new Vector3(0.25f, camHeight, 1f),
                    0f
                );
            }
            else
            {
                float yPos = bottomEdge + (i + 0.5f) * (camHeight / gridCount);
                SpawnLaser(
                    new Vector3(camCenter.x, yPos, -1f),
                    new Vector3(camWidth, 0.25f, 1f),
                    0f
                );
            }
        }
    }

    void SpawnLaser(Vector3 position, Vector3 scale, float rotationZ)
    {
        GameObject laserGO = Instantiate(laserPrefab, position, Quaternion.Euler(0f, 0f, rotationZ));
        Laser laser = laserGO.GetComponent<Laser>();

        if (laser != null)
        {
            laser.Init(scale);
        }
        else
        {
            Destroy(laserGO);
        }
    }
}
