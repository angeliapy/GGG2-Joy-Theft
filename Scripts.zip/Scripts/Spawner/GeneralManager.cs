using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GeneralManager : MonoBehaviour
{
    public TextMeshProUGUI timeText;

    private int totalSeconds = 0;
    private float timer = 0f;

    // Update is called once per frame
    void Update()
    {

        timer += Time.deltaTime;
        if (timer >= 1f)
        {
            int secondsPassed = Mathf.FloorToInt(timer);
            totalSeconds += secondsPassed;
            timer -= secondsPassed;
        }

        // compute minutes and seconds
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        if (timeText != null)
            timeText.text = string.Format("{0}:{1:00}", minutes, seconds);
    }
}
