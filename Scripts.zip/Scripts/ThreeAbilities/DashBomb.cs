using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class DashBomb : MonoBehaviour
{
    [Header("Damage Settings")]
    public float baseDPS = 4f;
    public float damagePerSecond;
    public float radius = 4.5f;
    public float duration = 2f;
    public float throwForce = 6f;

    [Header("Visuals")]
    public SpriteRenderer poisonCircle;
    public float pulseSpeed = 10f;
    public float pulseAmount = 0.15f;
    public float fadeOutTime = 0.6f;

    [Header("Layers")]
    public LayerMask enemyLayer;
    public LayerMask projectileLayer;

    private float timer;
    private Rigidbody2D rb;
    private Color poisonBaseColor;

    private float damageTickTimer = 0f;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        timer = duration;

        poisonBaseColor = poisonCircle.color;
        poisonCircle.transform.localScale = Vector3.one * radius * 2f;
    }

    public void Throw(Vector2 playerForward)
    {
        Vector2 throwDir = -playerForward.normalized;
        rb.AddForce(throwDir * throwForce, ForceMode2D.Impulse);
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        damagePerSecond = PlayerStats.GetDamage();
        HandlePulse();

        damageTickTimer += Time.deltaTime;
        if (damageTickTimer >= 0.5f)
        {
            DamageEnemies();
            DestroyProjectiles();
            damageTickTimer = 0f;
        }

        if (timer <= 0f)
        {
            StartCoroutine(FadeAndDie());
        }
    }

    void HandlePulse()
    {
        float pulse = 1f + Mathf.Sin(Time.time * pulseSpeed) * pulseAmount;
        poisonCircle.transform.localScale = Vector3.one * radius * 2f * pulse;
    }

    void DamageEnemies()
    {
        Collider2D[] hits = Physics2D.OverlapCircleAll(transform.position, radius, enemyLayer);

        foreach (Collider2D hit in hits)
        {
            if (hit.CompareTag("Enemy"))
            {
                Enemy enemy = hit.GetComponent<Enemy>();
                if (enemy != null)
                {
                    Vector2 dir = (hit.transform.position - transform.position).normalized;
                    enemy.TakeDamage((damagePerSecond + baseDPS + enemy.data.maxHealth * 0.2f) / 2f, dir);
                    Debug.Log(damagePerSecond + baseDPS);
                    Debug.Log("bruh " + (damagePerSecond + baseDPS) / 2f);
                }
            }
            if (hit.CompareTag("Boss"))
            {
                Boss boss = hit.GetComponent<Boss>();
                boss.TakeDamage((damagePerSecond + baseDPS) * 2f/2f);
            }
        }
    }

    void DestroyProjectiles()
    {
        Collider2D[] projectiles = Physics2D.OverlapCircleAll(transform.position, radius, projectileLayer);

        foreach (Collider2D proj in projectiles)
        {
            Destroy(proj.gameObject);
        }
    }

    IEnumerator FadeAndDie()
    {
        float t = 0f;
        Color startColor = poisonBaseColor;

        while (t < fadeOutTime)
        {
            t += Time.deltaTime;
            float alpha = Mathf.Lerp(startColor.a, 0f, t / fadeOutTime);
            poisonCircle.color = new Color(startColor.r, startColor.g, startColor.b, alpha);
            yield return null;
        }

        Destroy(gameObject);
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.magenta;
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
