﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeleeWeaponController : MonoBehaviour
{
    [Header("References")]
    public Transform weaponPivot;

    [Header("Stab Settings")]
    public float stabDistance = 0.4f;
    public float stabSpeed = 30f;
    public float returnSpeed = 20f;

    [Header("Attack Settings")]
    public bool isAttacking = false;

    private Vector3 originalLocalPos;
    private bool isStabbing;

    void Start()
    {
        originalLocalPos = weaponPivot.localPosition;
    }

    void Update()
    {
        RotateTowardMouse();
        if (isAttacking && !isStabbing)
            StartCoroutine(Stab());
    }

    void RotateTowardMouse()
    {
        Vector3 mouseWorld = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseWorld.z = 0f;

        Vector2 direction = (mouseWorld - weaponPivot.position).normalized;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        weaponPivot.rotation = Quaternion.Euler(0, 0, angle);
    }

    IEnumerator Stab()
    {
        isStabbing = true;

        Vector2 stabDir = (weaponPivot.right).normalized;
        Vector3 targetPos = originalLocalPos + (Vector3)(stabDir * stabDistance);

        //stab motion
        while (Vector3.Distance(weaponPivot.localPosition, targetPos) > 0.01f)
        {
            weaponPivot.localPosition = Vector3.MoveTowards(
                weaponPivot.localPosition,
                targetPos,
                stabSpeed * Time.deltaTime
            );
            yield return null;
        }

        // return motion
        while (Vector3.Distance(weaponPivot.localPosition, originalLocalPos) > 0.01f)
        {
            weaponPivot.localPosition = Vector3.MoveTowards(
                weaponPivot.localPosition,
                originalLocalPos,
                returnSpeed * Time.deltaTime
            );
            yield return null;
        }

        weaponPivot.localPosition = originalLocalPos;
        isStabbing = false;
    }
}
