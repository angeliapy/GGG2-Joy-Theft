using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// wait what is this....
/// </summary>
public class PlayerDashing : MonoBehaviour
{
    [Header("Dash Settings")]
    public float dashSpeed = 15f;
    public float dashDuration = 0.15f;
    public float baseCooldown = 0.5f;

    [Header("Bomb Settings")]
    public GameObject dashBombPrefab;
    public float bombSpawnOffset = 0.5f;

    [Header("Debug Info")]
    public bool isDashing = false;

    private Rigidbody2D rb;
    private Vector2 lastMoveInput;
    private float nextDashTime = 0f;

    private Collider2D playerCollider;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerCollider = GetComponent<Collider2D>();
    }

    // Update is called once per frame
    void Update()
    {
        lastMoveInput = new Vector2(
            Input.GetAxisRaw("Horizontal"),
            Input.GetAxisRaw("Vertical")
        ).normalized;

        
        float cooldown = PlayerStats.GetCooldown(baseCooldown);

        
        if (Input.GetKeyDown(KeyCode.Space) && Time.time >= nextDashTime)
        {
            StartCoroutine(Dash());
            nextDashTime = Time.time + cooldown;
        }
    }

    IEnumerator Dash()
    {
        if (lastMoveInput == Vector2.zero)
            lastMoveInput = transform.right;

        isDashing = true;

        // disalbe collider during dash
        if (playerCollider != null)
            playerCollider.enabled = false;

        
        if (dashBombPrefab != null)
        {
            Vector2 spawnPos = (Vector2)transform.position - lastMoveInput * bombSpawnOffset; // why doesn't it worktho
            Instantiate(dashBombPrefab, spawnPos, Quaternion.identity);
        }

        rb.velocity = lastMoveInput * dashSpeed;

        yield return new WaitForSeconds(dashDuration);

        rb.velocity = Vector2.zero;

        playerCollider.enabled = true;

        isDashing = false;
    }

}
