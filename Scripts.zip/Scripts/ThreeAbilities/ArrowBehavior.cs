using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArrowBehavior : MonoBehaviour
{
    public float damage = 2; // basedamage for arrow

    public float recoilForce = 5f;
    
    private Vector2 direction;
    public void Start()
    {
        damage += PlayerStats.GetDamage();
    }
    public void SetDirection(Vector2 dir)
    {
        direction = dir.normalized;
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Enemy"))
        {
            Enemy enemy = collision.GetComponent<Enemy>();
            enemy.TakeDamage(damage, direction);
            Destroy(gameObject);

        }
        if (collision.CompareTag("Boss"))
        {
            Boss boss = collision.GetComponent<Boss>();
            boss.TakeDamage(damage);
            Destroy(gameObject);
        }
        
    }
}
