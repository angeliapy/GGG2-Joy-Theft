using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class RangedWeaponController : MonoBehaviour
{
    [Header("References")]
    public Transform weaponPivot;

    [Header("Draw Settings")]
    public float drawDistance = 0.2f;
    public float drawSpeed = 15f;
    public float returnSpeed = 10f;

    [Header("Attack Settings")]
    public bool isAttacking = false;

    private Vector3 originalLocalPos;
    private bool isDrawing;

    // Start is called before the first frame update
    void Start()
    {
        originalLocalPos = weaponPivot.localPosition;
    }

    // Update is called once per frame
    void Update()
    {
        RotateTowardMouse();

        if (isAttacking && !isDrawing)
            StartCoroutine(DrawMotion());
    }

    void RotateTowardMouse()
    {
        Vector3 mouseWorld = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseWorld.z = 0f;

        Vector2 direction = (mouseWorld - weaponPivot.position).normalized;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;

        weaponPivot.rotation = Quaternion.Euler(0, 0, angle);
    }

    IEnumerator DrawMotion()
    {
        isDrawing = true;

        // local -right direction
        Vector2 drawDir = -weaponPivot.right.normalized;
        Vector3 targetPos = originalLocalPos + (Vector3)(drawDir * drawDistance);

        // Draw back motion
        while (Vector3.Distance(weaponPivot.localPosition, targetPos) > 0.01f)
        {
            weaponPivot.localPosition = Vector3.MoveTowards(
                weaponPivot.localPosition,
                targetPos,
                drawSpeed * Time.deltaTime
            );
            yield return null;
        }

        // Return bow to original position
        while (Vector3.Distance(weaponPivot.localPosition, originalLocalPos) > 0.01f)
        {
            weaponPivot.localPosition = Vector3.MoveTowards(
                weaponPivot.localPosition,
                originalLocalPos,
                returnSpeed * Time.deltaTime
            );
            yield return null;
        }

        weaponPivot.localPosition = originalLocalPos;
        isDrawing = false;
    }
}
