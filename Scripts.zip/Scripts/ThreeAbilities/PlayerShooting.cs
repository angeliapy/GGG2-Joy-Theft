using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerShooting : MonoBehaviour
{
    [Header("References")]
    public GameObject arrowPrefab;
    public Transform firePoint;

    [Header("Arrow Settings")]
    public float arrowSpeed = 10f;
    public float baseCooldown = 0.4f; // Editable in Inspector

    [Header("Draw Settings")]
    public Transform weaponPivot; // Bow pivot
    public float drawDistance = 0.2f;
    public float drawSpeed = 15f;
    public float returnSpeed = 10f;
    public GameObject weapon;
    private Rigidbody2D playerRb;
    private float nextShootTime = 0f;
    private bool isDrawing = false;
    private Vector3 originalLocalPos;
    void OnEnable()
    {
        if (weapon != null)
            weapon.SetActive(true);
    }

    void OnDisable()
    {
        if (weapon != null)
            weapon.SetActive(false);
    }
    // Start is called before the first frame update
    void Start()
    {
        playerRb = GetComponent<Rigidbody2D>();
        if (weaponPivot != null)
            originalLocalPos = weaponPivot.localPosition;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.z = 0f;
        Vector2 direction = ((Vector2)mousePos - (Vector2)firePoint.position).normalized;
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        firePoint.rotation = Quaternion.Euler(0, 0, angle);
        if (weaponPivot != null)
            weaponPivot.rotation = Quaternion.Euler(0, 0, angle);
        float cooldown = PlayerStats.GetCooldown(baseCooldown);

        if (Input.GetMouseButton(0) && Time.time >= nextShootTime && !isDrawing)
        {
            StartCoroutine(DrawAndShoot(direction, cooldown));
        }
    }

    IEnumerator DrawAndShoot(Vector2 direction, float cooldown)
    {
        if (weaponPivot != null)
            isDrawing = true;

        if (weaponPivot != null)
        {
            Vector2 drawDir = -weaponPivot.right.normalized;
            Vector3 targetPos = originalLocalPos + (Vector3)(drawDir * drawDistance);

            while (Vector3.Distance(weaponPivot.localPosition, targetPos) > 0.01f)
            {
                weaponPivot.localPosition = Vector3.MoveTowards(
                    weaponPivot.localPosition,
                    targetPos,
                    drawSpeed * Time.deltaTime
                );
                yield return null;
            }
        }

        Shoot(direction);

        if (weaponPivot != null)
        {
            while (Vector3.Distance(weaponPivot.localPosition, originalLocalPos) > 0.01f)
            {
                weaponPivot.localPosition = Vector3.MoveTowards(
                    weaponPivot.localPosition,
                    originalLocalPos,
                    returnSpeed * Time.deltaTime
                );
                yield return null;
            }

            weaponPivot.localPosition = originalLocalPos;
            isDrawing = false;
        }

        nextShootTime = Time.time + cooldown;
    }

    void Shoot(Vector2 direction)
    {
        if (arrowPrefab == null || firePoint == null) return;

        GameObject arrow = Instantiate(arrowPrefab, firePoint.position, firePoint.rotation);
        Rigidbody2D rb = arrow.GetComponent<Rigidbody2D>();

        if (rb != null)
            rb.velocity = (direction * arrowSpeed) + playerRb.velocity;
        ArrowBehavior arrowScript = arrow.GetComponent<ArrowBehavior>();
        if (arrowScript != null)
            arrowScript.SetDirection(direction);
    }
}
