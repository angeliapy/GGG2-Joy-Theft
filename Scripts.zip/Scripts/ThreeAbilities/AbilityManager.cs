using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class AbilityManager : MonoBehaviour
{
    public AbilityIconUI abilityIconUI;

    [Header("Abilities")]
    public PlayerShooting ps;
    public PlayerDashing pd;
    public PlayerMelee pm;
    public int maxWillpower = 5;
    private int currentWillpower;
    public WillpowerUI willpowerUI;

    [Header("Visual Effect")]
    public SpriteRenderer playerSprite;
    public Color flashColor = Color.cyan;
    public float scaleMultiplier = 0.8f;
    public float scaleSpeed = 10f;

    [Header("Character Roots")]
    public GameObject archerRoot;
    public GameObject speedyRoot;
    public GameObject tankRoot;

    private Vector3 originalScale;
    private enum Ability { Shooting, Dash, Melee }
    private Ability currentAbility;

    private PlayerMovement playerMovement;

    // Start is called before the first frame update
    void Start()
    {
        if (ps != null) ps.enabled = false;
        if (pd != null) pd.enabled = false;
        if (pm != null) pm.enabled = false;

        playerMovement = GetComponent<PlayerMovement>();
        originalScale = transform.localScale;

        currentWillpower = maxWillpower;

        if (willpowerUI != null)
            willpowerUI.InitializeBits(maxWillpower);
        currentAbility = Ability.Shooting;
        ActivateAbility(currentAbility);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1)) TrySwitchAbility(Ability.Shooting);
        if (Input.GetKeyDown(KeyCode.Alpha2)) TrySwitchAbility(Ability.Dash);
        if (Input.GetKeyDown(KeyCode.Alpha3)) TrySwitchAbility(Ability.Melee);
    }

    void TrySwitchAbility(Ability newAbility)
    {
        if (newAbility == currentAbility || currentWillpower <= 0)
            return;

        currentWillpower--;
        if (willpowerUI != null) willpowerUI.UpdateBits(currentWillpower);

        currentAbility = newAbility;
        ActivateAbility(currentAbility);
    }

    private void ActivateAbility(Ability ability)
    {
        ps.enabled = false;
        pd.enabled = false;
        pm.enabled = false;

        switch (ability)
        {
            case Ability.Shooting:
                Debug.Log("shooting");
                ps.enabled = true;
                abilityIconUI.SetAbilityIcon("Shooting");
                SetPlayerMovementRoot(archerRoot);
                playerSprite = archerRoot.GetComponent<SpriteRenderer>();
                break;
            case Ability.Dash:
                Debug.Log("dash");
                pd.enabled = true;
                abilityIconUI.SetAbilityIcon("Dash");
                SetPlayerMovementRoot(speedyRoot);
                playerSprite = speedyRoot.GetComponent<SpriteRenderer>();
                break;
            case Ability.Melee:
                Debug.Log("melee");
                pm.enabled = true;
                abilityIconUI.SetAbilityIcon("Melee");
                SetPlayerMovementRoot(tankRoot);
                playerSprite = tankRoot.GetComponent<SpriteRenderer>();
                break;
        }

        StartCoroutine(AbilityFlashEffect());
    }

    private void SetPlayerMovementRoot(GameObject root)
    {
        if (playerMovement == null) return;

        archerRoot.SetActive(root == archerRoot);
        speedyRoot.SetActive(root == speedyRoot);
        tankRoot.SetActive(root == tankRoot);

        playerMovement.spriteRoot = root.transform;
        playerMovement.animator = root.GetComponent<Animator>();
    }

    private IEnumerator AbilityFlashEffect()
    {
        if (playerSprite == null) yield break;

        Color originalColor = playerSprite.color;
        playerSprite.color = flashColor;

        Vector3 targetScale = originalScale * scaleMultiplier;
        float t = 0f;

        while (t < 1f)
        {
            t += Time.deltaTime * scaleSpeed;
            transform.localScale = Vector3.Lerp(originalScale, targetScale, t);
            yield return null;
        }

        t = 0f;
        while (t < 1f)
        {
            t += Time.deltaTime * scaleSpeed;
            transform.localScale = Vector3.Lerp(targetScale, originalScale, t);
            yield return null;
        }

        playerSprite.color = originalColor;
    }
}
