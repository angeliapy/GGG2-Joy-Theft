﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMelee : MonoBehaviour
{
    [Header("Melee Settings")]
    public Transform attackPoint;
    public float attackRange = 1f;
    public float attackDuration = 0.2f;
    public LayerMask enemyLayer;
    public GameObject weapon;
    public float baseCooldown = 0.5f;
    public float baseDamage = 0.5f;

    public MeleeWeaponController weaponController; 

    private Rigidbody2D playerRb;
    private bool hitstopTriggered;
    private float nextAttackTime = 0f;
    private float damage;

    void OnEnable()
    {
        if (weapon != null)
            weapon.SetActive(true);
    }

    void OnDisable()
    {
        if (weapon != null)
            weapon.SetActive(false);
    }

    // Start is called before the first frame update
    void Start()
    {
        playerRb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        damage = baseDamage + PlayerStats.GetDamage();
        float cooldown = PlayerStats.GetCooldown(baseCooldown);
        bool isAttacking = Input.GetMouseButton(0) && Time.time >= nextAttackTime;

        if (isAttacking)
        {
            Attack();
            nextAttackTime = Time.time + cooldown;
        }

        if (weaponController != null)
            weaponController.isAttacking = isAttacking;
    }

    void Attack()
    {
        hitstopTriggered = false;

        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.z = 0f;

        Vector2 direction = ((Vector2)mousePos - (Vector2)transform.position).normalized;
        Vector2 attackPos = (Vector2)transform.position + direction * attackRange;

        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(attackPos, attackRange, enemyLayer);

        foreach (Collider2D hit in hitEnemies)
        {
            if (hit.CompareTag("Enemy"))
            {
                Enemy enemy = hit.GetComponent<Enemy>();
                if (enemy != null)
                {
                    Vector2 dir = (hit.transform.position - transform.position).normalized;
                    enemy.TakeDamage(damage, dir);

                    if (!hitstopTriggered && Hitstop.Instance != null)
                    {
                        Hitstop.Instance.Stop(0.04f);
                        hitstopTriggered = true;
                    }
                }
            }

            if (hit.CompareTag("Boss"))
            {
                Boss boss = hit.GetComponent<Boss>();
                boss.TakeDamage(damage);

                if (Hitstop.Instance != null)
                {
                    Hitstop.Instance.Stop(0.04f);
                    hitstopTriggered = true;
                }
            }
        }
    }

    void OnDrawGizmosSelected()
    {
        if (attackPoint == null) return;
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(attackPoint.position, attackRange);
    }
}
