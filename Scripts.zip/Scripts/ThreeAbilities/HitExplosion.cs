using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitExplosion : MonoBehaviour
{
    [Header("Explosion Settings")]
    public float radius = 1.5f;
    public int damage = 1;
    public float force = 8f;
    public float lifetime = 0.1f;

    public LayerMask affectedLayers;

    // Start is called before the first frame update
    void Start()
    {
        Explode();
        Destroy(gameObject, lifetime);
    }

    void Explode()
    {
        Collider2D[] hits = Physics2D.OverlapCircleAll(
            transform.position,
            radius,
            affectedLayers
        );

        foreach (Collider2D col in hits)
        {
            Vector2 dir = (col.transform.position - transform.position).normalized;

            Enemy enemy = col.GetComponent<Enemy>();
            if (enemy != null)
            {
                enemy.TakeDamage(damage, dir);
            }

            PlayerMovement pm = col.GetComponent<PlayerMovement>();
            if (pm != null)
            {
                pm.ApplyKnockback(dir, force * 0.7f, 0.15f, 0.05f);
            }

            Rigidbody2D rb = col.GetComponent<Rigidbody2D>();
            if (rb != null)
            {
                rb.AddForce(dir * force, ForceMode2D.Impulse);
            }
        }
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.magenta;
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
