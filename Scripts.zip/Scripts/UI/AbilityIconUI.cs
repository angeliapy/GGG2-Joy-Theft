using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AbilityIconUI : MonoBehaviour
{
    [Header("UI Image")]
    public Image iconImage;

    [Header("Ability Icons")]
    public Sprite shootingIcon;
    public Sprite dashIcon;
    public Sprite meleeIcon;

    public void SetAbilityIcon(string abilityName)
    {
        switch (abilityName)
        {
            case "Shooting":
                iconImage.sprite = shootingIcon;
                break;

            case "Dash":
                iconImage.sprite = dashIcon;
                break;

            case "Melee":
                iconImage.sprite = meleeIcon;
                break;
        }
    }
}
