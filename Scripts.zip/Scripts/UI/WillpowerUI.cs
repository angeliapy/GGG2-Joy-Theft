using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WillpowerUI : MonoBehaviour
{
    [Header("UI Elements")]
    public GameObject willpowerPrefab;
    public Transform willpowerContainer;

    private List<GameObject> bits = new List<GameObject>();

    public void InitializeBits(int maxWillpower)
    {
        foreach (var b in bits)
            Destroy(b);
        bits.Clear();

        for (int i = 0; i < maxWillpower; i++)
        {
            GameObject bit = Instantiate(willpowerPrefab, willpowerContainer);
            bits.Add(bit);
        }
    }

    public void UpdateBits(int currentWillpower)
    {
        for (int i = bits.Count - 1; i >= currentWillpower; i--)
        {
            Destroy(bits[i]);
            bits.RemoveAt(i);
        }
    }
}
