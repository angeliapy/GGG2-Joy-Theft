using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HeartHealthUI : MonoBehaviour
{
    [Header("UI Elements")]
    public Image fillImage;  
    public Gradient healthGradient;

    private float maxHealth;

    // when player spawns
    public void Initialize()
    {
        maxHealth = PlayerStats.maxHealth;
        SetHealth(maxHealth);
    }

    
    public void SetHealth(float currentHealth)
    {
        if (maxHealth <= 0) return;

        float percent = (float)currentHealth / maxHealth;
        fillImage.fillAmount = Mathf.Clamp01(percent);

        if (healthGradient != null)
            fillImage.color = healthGradient.Evaluate(percent);
    }
}
