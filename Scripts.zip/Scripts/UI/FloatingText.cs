using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class FloatingText : MonoBehaviour
{
    public float moveSpeed = 1.5f;
    public float duration = 1f;
    public Color textColor = Color.red;

    private TextMeshProUGUI tmp;
    private float timer = 0f;

    // Start is called before the first frame update
    void Awake()
    {
        tmp = GetComponent<TextMeshProUGUI>();
        if (tmp != null)
            tmp.color = textColor;
    }

    // Update is called once per frame
    void Update()
    {
        // move upward
        transform.position += Vector3.up * moveSpeed * Time.deltaTime;

        // fade out over time
        timer += Time.deltaTime;
        if (timer >= duration)
        {
            Destroy(gameObject);
        }
        else
        {
            float alpha = Mathf.Lerp(1f, 0f, timer / duration);
            if (tmp != null)
                tmp.color = new Color(tmp.color.r, tmp.color.g, tmp.color.b, alpha);
        }
    }

    public void SetText(string text, Color color)
    {
        if (tmp != null)
        {
            tmp.text = text;
            tmp.color = color;
        }
    }
}
