using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpgradeScreen : MonoBehaviour
{
    public static UpgradeScreen Instance;
    public UpgradeManager um;


    void Awake()
    {
        Instance = this;
        gameObject.SetActive(false);
    }
    // Start is called before the first frame update
    void Start()
    {
        um = GetComponent<UpgradeManager>();
    }
    public void Show()
    {
        gameObject.SetActive(true);
        
        um.ShowUpgrades();
        Time.timeScale = 0f;
        
    }

    public void Hide()
    {
        gameObject.SetActive(false);
        Time.timeScale = 1f;
    }
}
