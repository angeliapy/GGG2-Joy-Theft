using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Boss : MonoBehaviour
{
    public float maxHealth = 50f;
    public float bobAmplitude = 0.3f;
    public float bobSpeed = 1.5f;
    public float healthMultiplier = 25f;
    public GameObject bossProjectile;
    public GameObject galloperPrefab;
    public GameObject crawlerPrefab;
    public GameObject flapperPrefab;
    public SpriteRenderer spriteRenderer;
    

    private EnemySpawner es;
    private LaserSpawner ls;
    private BossSpawner bs;
    private Transform player;

    private Rigidbody2D rb;
    public float projectileSpeed = 6f;

    private Color baseColor;
    public float currentHealth;
    private bool vulnerable;
    private float baseY;
    private Coroutine phaseRoutine;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        baseColor = spriteRenderer.color;
        GameObject spawner = GameObject.FindWithTag("Spawner");
        es = spawner.GetComponent<EnemySpawner>();
        ls = spawner.GetComponent<LaserSpawner>();
        bs = spawner.GetComponent<BossSpawner>();
        FindHealth();
        currentHealth = maxHealth;
        Debug.Log("current helaht:" + currentHealth.ToString());
        player = GameObject.FindGameObjectWithTag("Player").transform;
        baseY = transform.position.y;
        phaseRoutine = StartCoroutine(PhaseController());
        

    }
    // Update is called once per frame
    void Update()
    {
        float yOffset = Mathf.Sin(Time.time * bobSpeed) * bobAmplitude;
        transform.position = new Vector3(transform.position.x, baseY + yOffset, transform.position.z);
    }

    IEnumerator PhaseController()
    {
        while (true)
        {
            int day = es.currentDay;

            if (day >= 5)
            {
                yield return StartCoroutine(FinalDayPhase());
            }
            else
            {
                switch (day)
                {
                    case 1: yield return StartCoroutine(Phase1()); break;
                    case 2: yield return StartCoroutine(Phase2()); break;
                    case 3: yield return StartCoroutine(Phase3()); break;
                    case 4: yield return StartCoroutine(Phase4()); break;
                }
            }

            yield return StartCoroutine(VulnerabilityPhase());
        }
    }

    IEnumerator Phase1()
    {
        float timer = 10f;
        while (timer > 0)
        {
            timer -= Time.deltaTime - 1.2f;
            FireRadialProjectiles(Random.Range(8, 16));
            FireRandomProjectile();
            FireRandomProjectile();
            FireRandomProjectile();
            yield return new WaitForSeconds(0.6f);
        }
    }

    IEnumerator Phase2()
    {
        float timer = Random.Range(10f, 20f);
        while (timer > 0)
        {
            timer -= Time.deltaTime;
            Instantiate(galloperPrefab, RandomSpawnPosition(), Quaternion.identity);
            yield return new WaitForSeconds(1f);
        }
    }

    IEnumerator Phase3()
    {
        ls.StartLasers();
        float timer = Random.Range(10f, 20f);
        while (timer > 0)
        {
            timer -= Time.deltaTime;
            FireRandomProjectile();
            FireRandomProjectile();
            FireRandomProjectile();
            FireRandomProjectile();
            FireRandomProjectile();
            FireRandomProjectile();
            FireRandomProjectile();
            FireRandomProjectile();//bruh
            yield return new WaitForSeconds(Random.Range(1.5f, 3f));
        }
    }

    IEnumerator Phase4()
    {
        Instantiate(crawlerPrefab, RandomSpawnPosition(), Quaternion.identity);
        float timer = Random.Range(10f, 20f);
        while (timer > 0)
        {
            timer -= Time.deltaTime;
            Instantiate(flapperPrefab, RandomSpawnPosition(), Quaternion.identity);
            yield return new WaitForSeconds(0.5f);
        }
    }

    IEnumerator FinalDayPhase()
    {
        float timer = Random.Range(15f, 25f);
        ls.StartLasers();

        while (timer > 0)
        {
            timer -= Time.deltaTime;

            FireRadialProjectiles(12);
            FireRandomProjectile();

            Instantiate(galloperPrefab, RandomSpawnPosition(), Quaternion.identity);
            Instantiate(flapperPrefab, RandomSpawnPosition(), Quaternion.identity);

            if (Random.value < 0.3f)
                Instantiate(crawlerPrefab, RandomSpawnPosition(), Quaternion.identity);

            yield return new WaitForSeconds(1f);
        }
    }

    IEnumerator VulnerabilityPhase()
    {
        vulnerable = true;
        yield return new WaitForSeconds(4f);
        vulnerable = false;
    }

    void FireRadialProjectiles(int count)
    {
        float angleStep = 360f / count;
        for (int i = 0; i < count; i++)
        {
            float angle = angleStep * i; // in degrees
            float angleRad = angle * Mathf.Deg2Rad;
            Vector2 dir = new Vector2(Mathf.Cos(angleRad), Mathf.Sin(angleRad));

            Quaternion rotation = Quaternion.Euler(0f, 0f, angle + 180);
            GameObject proj = Instantiate(bossProjectile, transform.position, rotation);

            proj.GetComponent<Rigidbody2D>().velocity = dir * projectileSpeed;
        }
    }

    void FireRandomProjectile()
    {
        Vector2 dir = Random.insideUnitCircle.normalized;
        GameObject proj = Instantiate(bossProjectile, transform.position, Quaternion.identity);
        proj.GetComponent<Rigidbody2D>().velocity = dir * projectileSpeed;
    }

    Vector3 RandomSpawnPosition()
    {
        // can't spawn in radius of player
        if (Vector3.Distance(transform.position, player.position) < 1.5)
        {
            return transform.position;
        }
        float x = Random.Range(-8f, 8f);
        float y = Random.Range(-3f, 4f);
        return new Vector3(x, y, 0f);
    }
    public void FindHealth()
    {
        maxHealth = maxHealth + healthMultiplier * es.currentDay;
    }
    public void TakeDamage(float amount)
    {

        if (vulnerable)
        {
            amount *= 2f;
            StartCoroutine(HitFlashVul());
        } else
        {
            StartCoroutine(HitFlash());
        }

        currentHealth -= amount;

        if (currentHealth <= 0)
            Die();
    }
    private IEnumerator HitFlash()
    {
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.1f);
        spriteRenderer.color = baseColor;
    }
    private IEnumerator HitFlashVul()
    {
        spriteRenderer.color = Color.magenta;
        yield return new WaitForSeconds(0.1f);
        spriteRenderer.color = baseColor;
    }
    void Die()
    {
        StopAllCoroutines();

        

        // so this isnt even using phase4? or5
        if (es.currentDay >= 4)
        {
            // Load the Victory Scene
            SceneManager.LoadScene("Victory"); 
        } else
        {
            bs.OnBossDefeated();
        }

        Destroy(gameObject);
    }
    IEnumerator LoadVictoryAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        SceneManager.LoadScene("Victory"); // make sure this matches your scene name
    }

}
