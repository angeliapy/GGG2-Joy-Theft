using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Enemy : MonoBehaviour
{
    [Header("References")]
    public EnemyData data;
    public Transform player;
    public SpriteRenderer spriteRenderer;
    public GameObject xpOrbPrefab;
    public GameObject floatingTextPrefab;

    public float recoilForce = 5f;

    [Header("Variation")]
    public float sizeVariation = 0.15f;
    public float colorVariation = 0.08f;

    private Rigidbody2D rb;
    private float currentHealth;
    public event Action onDeath;

    // kb
    private Vector2 knockbackVelocity = Vector2.zero;
    private float knockbackDecay = 10f;

    private float fireTimer = 0f;

    private Color baseColor;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        
        float scaleFactor = UnityEngine.Random.Range(1f - sizeVariation, 1f + sizeVariation);

       
        Color c = data.color;
        c.r = Mathf.Clamp01(c.r + UnityEngine.Random.Range(-colorVariation, colorVariation));
        c.g = Mathf.Clamp01(c.g + UnityEngine.Random.Range(-colorVariation, colorVariation));
        c.b = Mathf.Clamp01(c.b + UnityEngine.Random.Range(-colorVariation, colorVariation));
        baseColor = c;

        spriteRenderer.color = baseColor;
        spriteRenderer.sprite = data.sprite;

        transform.localScale = new Vector3(
            data.size.x * scaleFactor,
            data.size.y * scaleFactor,
            1f
        );

        currentHealth = data.maxHealth;

        if (player == null)
            player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
        Vector2 toPlayer = (player.position - transform.position);
        Vector2 direction = toPlayer.normalized;

        if (direction.x != 0)
            spriteRenderer.flipX = direction.x > 0;
        if (data.isRanged)
        {
            rb.velocity = knockbackVelocity;
            HandleRangedAttack(direction);
        }
       
            Vector2 movement = direction * data.moveSpeed;
            movement += knockbackVelocity;
            rb.velocity = movement;
   
        knockbackVelocity = Vector2.Lerp(
            knockbackVelocity,
            Vector2.zero,
            knockbackDecay * Time.fixedDeltaTime
        );
    }

    void HandleRangedAttack(Vector2 direction)
    {
        if (!spriteRenderer.isVisible)
        {
            return;
        }
        fireTimer -= Time.fixedDeltaTime;
        if (fireTimer > 0f) return;

        fireTimer = data.fireRate;
        FireProjectile(direction);
    }

    void FireProjectile(Vector2 direction)
    {
        if (data.projectilePrefab == null) return;

        GameObject proj = Instantiate(
            data.projectilePrefab,
            transform.position,
            Quaternion.identity
        );


        Rigidbody2D prb = proj.GetComponent<Rigidbody2D>();
        prb.velocity = direction * data.projectileSpeed;

        ArrowBehavior arrow = proj.GetComponent<ArrowBehavior>();
        arrow.SetDirection(direction);
    }

    public void TakeDamage(float damage, Vector2 hitDirection)
    {
        currentHealth -= damage;

        Vector3 spawnPos = transform.position;
        Canvas canvas = GameObject.FindGameObjectWithTag("Canvas").GetComponent<Canvas>();
        GameObject ft = Instantiate(floatingTextPrefab, spawnPos + Vector3.up, Quaternion.identity, canvas.transform);
        FloatingText ftScript = ft.GetComponent<FloatingText>();
        ftScript.SetText(damage.ToString("0.0"), Color.red); //floating tenth decima;

        StartCoroutine(HitFlash());
        knockbackVelocity = hitDirection.normalized * recoilForce;

        if (currentHealth <= 0)
            Die();
    }

    private IEnumerator HitFlash()
    {
        spriteRenderer.color = Color.red;
        yield return new WaitForSeconds(0.1f);
        spriteRenderer.color = baseColor;
    }

    private void Die()
    {
        if (xpOrbPrefab != null)
        {
            Instantiate(
                xpOrbPrefab,
                transform.position,
                Quaternion.identity
            );
        }

        onDeath?.Invoke();
        Destroy(gameObject);
    }

}
