using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "EnemyData", menuName = "ScriptableObjects/EnemyData")]
public class EnemyData : ScriptableObject
{
    [Header("Visuals")]
    public Sprite sprite;
    public Vector2 size = Vector2.one;
    public Color color = Color.white;

    [Header("Stats")]
    public float moveSpeed = 3f;
    public int maxHealth = 3;
    public bool isRanged = false;

    [Header("Ranged Settings")]
    public GameObject projectilePrefab;
    public float fireRate = 1.5f;
    public float projectileSpeed = 6f;
}
