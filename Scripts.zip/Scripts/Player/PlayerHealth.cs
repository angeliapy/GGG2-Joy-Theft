using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class PlayerHealth : MonoBehaviour
{
    public float maxHealth;
    public float currentHealth;

    [Header("Damage Feedback")]
    public SpriteRenderer spriteRenderer;
    public Color hitColor = Color.red;
    public float flashDuration = 0.1f;
    public int flashCount = 5;

    [Header("Invincibility")]
    public float invincibilityDuration = 1f;
    private bool isInvincible = false;

    public HeartHealthUI healthBarUI;
    public GameObject hitExplosionPrefab; // i am not using this anymore 12/25 :sob

    // Start is called before the first frame update
    void Start()
    {
        maxHealth = PlayerStats.maxHealth;
        PlayerStats.currentHealth = maxHealth;
        healthBarUI.Initialize();
    }

    // Update is called once per frame
    void Update()
    {
        if (currentHealth < maxHealth)
        {
            PlayerStats.currentHealth += PlayerStats.GetHealthRegen() * Time.deltaTime;
        }
        

        healthBarUI.SetHealth(PlayerStats.currentHealth);
        if (PlayerStats.currentHealth <= 0)
            Die();
    }

    public void TakeDamage(float damage)
    {
        Debug.Log("TOOK DAMAGE FROM SMTH");
        Debug.Log("curre health" + PlayerStats.currentHealth);
        if (isInvincible) return;

        PlayerStats.currentHealth -= damage;



        if (hitExplosionPrefab != null)
        {
            Instantiate(hitExplosionPrefab, transform.position, Quaternion.identity);
        }

        StartCoroutine(HitFlash());

        
    }

    private IEnumerator HitFlash()
    {
        isInvincible = true;

        Color originalColor = spriteRenderer.color;

        for (int i = 0; i < flashCount; i++)
        {
            spriteRenderer.color = hitColor;
            yield return new WaitForSeconds(flashDuration);
            spriteRenderer.color = originalColor;
            yield return new WaitForSeconds(flashDuration);
        }

        float remainingTime = invincibilityDuration - (flashCount * 2 * flashDuration);
        if (remainingTime > 0)
            yield return new WaitForSeconds(remainingTime);

        isInvincible = false;
    }

    private void Die()
    {
        Debug.Log("YOU DIED.");
        
        SceneManager.LoadScene("DeathScene");
    }
}
