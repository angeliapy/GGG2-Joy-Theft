using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// STATIC CLASS!!!!!!!!!!!!!!!!!!!!!!!!!!!!
/// </summary>
public static class PlayerStats
{
    // core stats
    public static float baseCooldown = 1f;
    public static float baseMoveSpeed = 3f;
    public static float maxHealth = 10f;
    public static float currentHealth = 10f;
    public static float incomingDamage = 1f;

    // passive stats
    public static float healthRegenPerSecond = 0.05f;
    public static float healthRegenMultiplier = 1f;

    // multipliers&addition
    public static float damageAddition = 0f;
    public static float cooldownMultiplier = 1f;
    public static float moveSpeedMultiplier = 1f;

    // xp and enemyproj. 
    public static float xpGainMultiplier = 1f;
    public static float enemyMoveSpeedMultiplier = 1f;
    public static float enemyProjectileMultiplier = 1f;

    // GET stats
    public static float GetDamage()
    {
        return damageAddition;
    }

    public static float GetCooldown(float originalCooldown)
    {
        return originalCooldown * cooldownMultiplier;
    }

    public static float GetMoveSpeed()
    {
        return baseMoveSpeed * moveSpeedMultiplier;
    }

    public static float GetXPGain(float baseXP)
    {
        return baseXP * xpGainMultiplier;
    }

    public static float GetEnemyMoveSpeed(float enemyBaseSpeed)
    {
        return enemyBaseSpeed * enemyMoveSpeedMultiplier;
    }

    public static float GetEnemyProjectileSpeed(float projectileBaseSpeed)
    {
        return projectileBaseSpeed * enemyProjectileMultiplier;
    }
    public static float GetHealthRegen()
    {
        return healthRegenPerSecond * healthRegenMultiplier;
    }

    // applyupgrades
    public static void ApplyDamageUpgrade(float add)
    {
        damageAddition = add;
    }

    public static void ApplyCooldownUpgrade(float multiplier)
    {
        cooldownMultiplier = multiplier;
    }

    public static void ApplyMoveSpeedUpgrade(float multiplier)
    {
        moveSpeedMultiplier = multiplier;
    }

    public static void ApplyXPGainUpgrade(float multiplier)
    {
        xpGainMultiplier = multiplier;
    }

    public static void ApplyHealthRegenUpgrade(float value)
    {
        healthRegenPerSecond = value;
    }

    public static void ApplyEnemyMoveSlow(float multiplier)
    {
        enemyMoveSpeedMultiplier = multiplier;
    }

    public static void ApplyEnemyProjectileSlow(float multiplier)
    {
        enemyProjectileMultiplier = multiplier;
    }
}
