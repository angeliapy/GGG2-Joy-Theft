using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class PlayerCollision : MonoBehaviour
{
    public PlayerHealth health; 
    public float damageAmount; 
    public float knockbackForce = 6f;
    public float knockbackDuration = 0.2f;
    public float postKnockbackPause = 0.05f;

    private PlayerMovement pm;

    // Start is called before the first frame update
    void Start()
    {
        pm = GetComponent<PlayerMovement>();
        if (health == null)
            health = GetComponent<PlayerHealth>();
    }
    // Update is called once per frame
    void Update()
    {
        damageAmount = PlayerStats.incomingDamage;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy") )
        {
            health.TakeDamage(damageAmount);

            Vector2 knockbackDir = (transform.position - collision.transform.position).normalized;
            pm.ApplyKnockback(knockbackDir, knockbackForce, knockbackDuration, postKnockbackPause);
        }
        if (collision.gameObject.CompareTag("Boss"))
        {
            health.TakeDamage(damageAmount * 3);

        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Laser") || collision.gameObject.CompareTag("EnemyProjectile"))
        {
            health.TakeDamage(damageAmount);
            // tiny knockback in half
            Vector2 knockbackDir = (transform.position - collision.transform.position).normalized;
            pm.ApplyKnockback(knockbackDir, knockbackForce / 2, knockbackDuration / 2, postKnockbackPause / 2);

        }

    }
}
