using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed;
    private Rigidbody2D rb;
    private Vector2 movement;
    public Animator animator;
    private PlayerDashing pd;
    public Transform spriteRoot;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        pd = GetComponent<PlayerDashing>();
        animator = spriteRoot.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if ((pd == null || !pd.isDashing) && !isKnockedback)
        {
            movement.x = Input.GetAxisRaw("Horizontal");
            movement.y = Input.GetAxisRaw("Vertical");
            movement = movement.normalized;
            
        }
        if (movement.x != 0)
        {
            Vector3 scale = spriteRoot.localScale;
            scale.x = Mathf.Abs(scale.x) * Mathf.Sign(movement.x);
            spriteRoot.localScale = scale;
        }
        animator.SetFloat("Speed", movement.magnitude);
        moveSpeed = PlayerStats.GetMoveSpeed();
    }

    private void FixedUpdate()
    {
        if (pd != null && pd.isDashing)
            return;

        if (!isKnockedback)
        {
            rb.MovePosition(rb.position + movement * moveSpeed * Time.fixedDeltaTime);
        }
    }

    private bool isKnockedback = false;

    public void ApplyKnockback(Vector2 direction, float force, float knockbackDuration = 0.2f, float postPauseDuration = 0.1f)
    {
        StartCoroutine(KnockbackCoroutine(direction.normalized * force, knockbackDuration, postPauseDuration));
    }

    private IEnumerator KnockbackCoroutine(Vector2 velocity, float knockbackDuration, float postPauseDuration)
    {
        isKnockedback = true;
        rb.velocity = velocity;
        yield return new WaitForSeconds(knockbackDuration);

        rb.velocity = Vector2.zero;
        yield return new WaitForSeconds(postPauseDuration);

        isKnockedback = false;
    }
}
