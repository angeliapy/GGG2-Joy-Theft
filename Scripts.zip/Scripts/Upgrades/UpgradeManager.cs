using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpgradeManager : MonoBehaviour
{
    [Header("UI")]
    public Transform upgradeContainer; // hor layout group!!!!
    public GameObject skillCardPrefab;
    public int numberOfUpgrades = 3;
    public List<Sprite> skillCardSprites;
    public List<Sprite> overlaySprites;

    [Header("References")]
    public UpgradeScreen us;
    public BossSpawner bs;


    [Header("Upgrades")]
    public List<UpgradeData> allUpgrades;
    public Dictionary<UpgradeData, UpgradeRuntime> runtimeUpgrades; // data : .currentLevel

    private List<UpgradeInstance> activeCards = new List<UpgradeInstance>();
    public void Awake()
    {
        runtimeUpgrades = new Dictionary<UpgradeData, UpgradeRuntime>();

        foreach (var upgrade in allUpgrades)
        {
            runtimeUpgrades[upgrade] = new UpgradeRuntime
            {
                data = upgrade,
                currentLevel = 0
            };
        }
        
    }
    public int GetLevel(UpgradeData data)
    {
        return runtimeUpgrades[data].currentLevel;
    }
    public UpgradeRuntime GetUR(UpgradeData data)
    {
        return runtimeUpgrades[data];
    }
    public Sprite GetCardSprite(int currentLevel)
    {
        return skillCardSprites[currentLevel];
    }
    public Sprite GetOverlaySprite(int currentLevel)
    {
        return overlaySprites[currentLevel];
    }
    public void ShowUpgrades()
    {
        ClearUpgradeCards();

        
        List<UpgradeData> availableUpgrades = new List<UpgradeData>();
        foreach (var u in allUpgrades)
        {
            if (GetLevel(u) < u.maxLevel) // not maxed out
                availableUpgrades.Add(u);
        }

        
        for (int i = 0; i < availableUpgrades.Count; i++)
        {
            int rnd = Random.Range(i, availableUpgrades.Count); // random shuffle
            var temp = availableUpgrades[i];
            availableUpgrades[i] = availableUpgrades[rnd];
            availableUpgrades[rnd] = temp;
        }

        int upgradesToShow = Mathf.Min(numberOfUpgrades, availableUpgrades.Count);

        for (int i = 0; i < upgradesToShow; i++)
        {
            UpgradeData u = availableUpgrades[i];
            GameObject cardObj = Instantiate(skillCardPrefab, upgradeContainer);
            UpgradeInstance ui = cardObj.GetComponent<UpgradeInstance>();
            ui.Setup(u, this, GetUR(u));  //o
            activeCards.Add(ui);
        }
    }

    public void ClearUpgradeCards()
    {
        foreach (var card in activeCards)
        {
           Destroy(card.gameObject);
        }
        activeCards.Clear();
    }
    public void End()
    {
        us.Hide();
        bs.SpawnBoss();
        
    }
    public void SelectUpgrade(UpgradeData upgrade, UpgradeRuntime ur)
    {
        if (ur.currentLevel >= upgrade.maxLevel) return;

        ur.AttemptLevelUp(); // this isnt attempt its just level up.
        ApplyUpgradeEffect(upgrade, ur);
        ClearUpgradeCards();
        End();
    }

    private void ApplyUpgradeEffect(UpgradeData upgrade, UpgradeRuntime ur)
    {
        Debug.Log("APPLIED UPGRADE:" + upgrade.ToString());
        switch (upgrade.type)
        {
            case UpgradeType.Damage:
                PlayerStats.ApplyDamageUpgrade(upgrade.GetMultiplier(ur));
                break;
            case UpgradeType.Cooldown:
                PlayerStats.ApplyCooldownUpgrade(upgrade.GetMultiplier(ur));
                break;
            case UpgradeType.MoveSpeed:
                PlayerStats.ApplyMoveSpeedUpgrade(upgrade.GetMultiplier(ur));
                break;
            case UpgradeType.HealthRegen:
                PlayerStats.ApplyHealthRegenUpgrade(upgrade.GetMultiplier(ur));
                break;
            case UpgradeType.XPGain:
                PlayerStats.ApplyXPGainUpgrade(upgrade.GetMultiplier(ur));
                break;
            case UpgradeType.EnemyMoveSlow:
                PlayerStats.ApplyEnemyMoveSlow(upgrade.GetMultiplier(ur));
                break;
            case UpgradeType.EnemyProjectileSlow:
                PlayerStats.ApplyEnemyProjectileSlow(upgrade.GetMultiplier(ur));
                break;
        }
    }
}
