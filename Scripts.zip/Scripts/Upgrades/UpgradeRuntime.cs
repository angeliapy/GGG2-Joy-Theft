using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class UpgradeRuntime
{
    public UpgradeData data;
    public int currentLevel  = 0;


    public void AttemptLevelUp()
    {
        currentLevel++;
    }
}
