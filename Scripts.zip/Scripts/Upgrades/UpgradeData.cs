using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum UpgradeType
{
    Damage,
    Cooldown,
    MoveSpeed,
    HealthRegen,
    XPGain,
    EnemyMoveSlow,
    EnemyProjectileSlow,
}

[CreateAssetMenu(fileName = "Upgrade", menuName = "Upgrades/Upgrade")]
public class UpgradeData : ScriptableObject
{
    
    public UpgradeType type;

    public int maxLevel = 2; // 0 1 2


    public Sprite baseIcon;

    public float[] multipliers;      // ok im calling it a "multiplier" even tho damage is not..

    
    public string GetString(UpgradeRuntime ur)
    {
        if (type == UpgradeType.Damage)
        {
            return "+" + GetMultiplier(ur);
        }
        return "x" + GetMultiplier(ur);
    }

    public float GetMultiplier(UpgradeRuntime ur)
    {

        
        return multipliers[ur.currentLevel];
    }


}
