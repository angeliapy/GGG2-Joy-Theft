using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UpgradeInstance : MonoBehaviour
{
    public Image cardImage;
    public Image baseIconImage;
    public Image overlayIconImage;
    public Button button;
    public TextMeshProUGUI upgradeText;


    private UpgradeData upgrade;
    private UpgradeManager manager;

    public void Setup(UpgradeData u, UpgradeManager m, UpgradeRuntime ur)
    {
        Debug.Log("setting up skillcard");
        upgrade = u;
        manager = m;
        int currentLevel = manager.GetLevel(u);

        cardImage.sprite = m.GetCardSprite(currentLevel); // get skjkll card sprite based on level
        Debug.Log("curre level:" + currentLevel.ToString() + " annd" + m.GetCardSprite(currentLevel).name);
        overlayIconImage.sprite = m.GetOverlaySprite(currentLevel);
        upgradeText.SetText(u.name + " -> " + u.GetString(ur));

        baseIconImage.sprite = u.baseIcon; //need to get base icons sprite for?
        button.onClick.RemoveAllListeners();
        button.onClick.AddListener(() => manager.SelectUpgrade(upgrade, ur));
        
    }
}
