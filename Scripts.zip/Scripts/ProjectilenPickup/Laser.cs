﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser : MonoBehaviour
{
    [Header("Timing")]
    public float warningTime = 1f;
    public float slideTime = 0.25f;
    public float activeTime = 1.5f;
    public float fadeOutTime = 0.3f;

    [Header("Combat")]
    public int damage = 1;

    [Header("Movement")]
    public Vector2 slideOffset;

    private SpriteRenderer sr;
    private BoxCollider2D col;
    private Color baseColor;

    // Start is called before the first frame update
    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        col = GetComponent<BoxCollider2D>();

        col.enabled = false;
        baseColor = Color.magenta;
    }

    // Called by spawner
    public void Init(Vector3 scale)
    {
        transform.localScale = scale;
        StartCoroutine(LaserRoutine());
    }

    IEnumerator LaserRoutine()
    {
        Vector3 finalPos = transform.position;
        Vector3 startPos = finalPos + (Vector3)slideOffset;
        transform.position = startPos;

        float t = 0f;
        while (t < warningTime)
        {
            float pulse = Mathf.PingPong(Time.time * 4f, 1f);
            sr.color = new Color(1f, 0f, 1f, 0.25f + pulse * 0.25f);
            t += Time.deltaTime;
            yield return null;
        }

        t = 0f;
        while (t < slideTime)
        {
            float p = t / slideTime;
            transform.position = Vector3.Lerp(startPos, finalPos, p);
            sr.color = new Color(1f, 0f, 1f, Mathf.Lerp(0.4f, 1f, p));
            t += Time.deltaTime;
            yield return null;
        }

        sr.color = baseColor;
        col.enabled = true;

        yield return new WaitForSeconds(activeTime);

        t = 0f;
        while (t < fadeOutTime)
        {
            float a = Mathf.Lerp(1f, 0f, t / fadeOutTime);
            sr.color = new Color(1f, 0f, 1f, a);
            t += Time.deltaTime;
            yield return null;
        }

        Destroy(gameObject);
    }

   
}
