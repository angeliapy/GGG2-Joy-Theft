using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class XPOrb : MonoBehaviour
{
    [Header("XP")]
    public int xpAmount = 1;

    [Header("Attraction")]
    public float attractRadius = 2f;
    public float attractDelay = 0.5f;
    public float maxMoveSpeed = 6f;
    public float acceleration = 3f;
    public float collectDistance = 0.2f;

    [Header("Idle Motion")]
    public float bobAmplitude = 0.15f;
    public float bobFrequency = 2f;

    private Transform player;
    private EnemySpawner spawner;

    private Vector3 startPos;
    private float currentSpeed = 0f;

    private bool isWaitingToAttract = false;
    private bool isAttracting = false;
    private float delayTimer = 0f;

    // Start is called before the first frame update
    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player")?.transform;
        spawner = FindObjectOfType<EnemySpawner>();

        startPos = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        if (player == null || spawner == null) return;

        float distance = Vector2.Distance(transform.position, player.position);

        if (!isAttracting)
        {
            transform.position = startPos +
                Vector3.up * Mathf.Sin(Time.time * bobFrequency) * bobAmplitude;

            if (distance <= attractRadius && !isWaitingToAttract)
            {
                isWaitingToAttract = true;
                delayTimer = attractDelay;
            }
        }

        if (isWaitingToAttract && !isAttracting)
        {
            delayTimer -= Time.deltaTime;
            if (delayTimer <= 0f)
            {
                isWaitingToAttract = false;
                isAttracting = true;
            }
        }

        if (isAttracting)
        {
            // Accelerate smoothly
            currentSpeed = Mathf.MoveTowards(
                currentSpeed,
                maxMoveSpeed,
                acceleration * Time.deltaTime
            );

            Vector3 dir = (player.position - transform.position).normalized;
            transform.position += dir * currentSpeed * Time.deltaTime;

            if (distance <= collectDistance)
                Collect();
        }
    }

    void Collect()
    {
        spawner.AddXP(xpAmount);
        Destroy(gameObject);
    }
}
