using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UniversalProjectile : MonoBehaviour
{
    [Header("Lifetime")]
    public float lifetime = 3f;
    public float fadeDuration = 0.5f;

    [Header("Visual Effects")]
    public bool fadeOut = true;
    public bool shrink = false;
    public bool rotate = false;
    public float rotationSpeed = 360f;

    [Header("Motion")]
    public Rigidbody2D rb;
    public float slowDownMultiplier = 1f; // 1 = no slow, <1 = slow before death

    private SpriteRenderer sr;
    private Color originalColor;
    private Vector3 originalScale;
    private bool isFading = false;

    void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        originalColor = sr.color;
        originalScale = transform.localScale;

        if (rb == null)
            rb = GetComponent<Rigidbody2D>();
    }

    // Start is called before the first frame update
    void Start()
    {
        Invoke(nameof(BeginFade), lifetime);
    }

    // Update is called once per frame
    void Update()
    {
        if (rotate)
            transform.Rotate(0f, 0f, rotationSpeed * Time.deltaTime);
    }

    void BeginFade()
    {
        if (!isFading)
            StartCoroutine(FadeRoutine());
    }

    IEnumerator FadeRoutine()
    {
        isFading = true;

        float t = 0f;
        Color startColor = sr.color;

        while (t < fadeDuration)
        {
            float p = t / fadeDuration;

            // Fade alpha
            if (fadeOut)
                sr.color = new Color(startColor.r, startColor.g, startColor.b, 1f - p);

            // Shrink
            if (shrink)
                transform.localScale = Vector3.Lerp(originalScale, Vector3.zero, p);

            // Slow down
            if (rb != null && slowDownMultiplier < 1f)
                rb.velocity *= Mathf.Lerp(1f, slowDownMultiplier, p);

            t += Time.deltaTime;
            yield return null;
        }

        Destroy(gameObject);
    }
}
